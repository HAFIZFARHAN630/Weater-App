const apiKey = "f2d781b13e5a447892774059252105";
const apiUrl = "http://api.weatherapi.com/v1/current.json?key=" + apiKey + "&q=";

const searchBox = document.querySelector(".search input");
const searchBtn = document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");

async function checkWeather(city) {
    try {
        const response = await fetch(apiUrl + city + "&aqi=yes");

        if (!response.ok) {
            throw new Error("City not found or invalid API key");
        }

        const data = await response.json();
        console.log(data); // See the result in browser console

        document.querySelector(".city").innerHTML = data.location.name;
        document.querySelector(".temp").innerHTML = Math.round(data.current.temp_c) + "°C";
        document.querySelector(".humidity").innerHTML = data.current.humidity + "%";
        document.querySelector(".wind").innerHTML = data.current.wind_kph + " km/h";

        // Weather condition for icon
        const condition = data.current.condition.text.toLowerCase();

        if (condition.includes("cloud")) {
            weatherIcon.src = "images/clouds.png";
        } else if (condition.includes("clear")) {
            weatherIcon.src = "images/clear.png";
        } else if (condition.includes("rain")) {
            weatherIcon.src = "images/rain.png";
        } else if (condition.includes("drizzle")) {
            weatherIcon.src = "images/drizzle.png";
        } else if (condition.includes("mist") || condition.includes("fog")) {
            weatherIcon.src = "images/mist.png";
        } else {
            weatherIcon.src = "images/clear.png";
        }

    } catch (error) {
        console.error("Error fetching weather:", error.message);
        alert("Error: " + error.message);
    }
}

searchBtn.addEventListener("click", () => {
    const city = searchBox.value.trim();
    if (city !== "") {
        checkWeather(city);
    }
});
